document.querySelectorAll(".card").forEach(card => {
    card.addEventListener("mousemove", e => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      card.style.background =
        `radial-gradient(circle at ${x}px ${y}px, rgba(46,252,255,0.18), #070b15 65%)`;
    });
  
    card.addEventListener("mouseleave", () => {
      card.style.background = "linear-gradient(180deg, #0c1324, #070b15)";
    });
  });